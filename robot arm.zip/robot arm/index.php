
<!DOCTYPE html>
<html>
<head>
    <title>Robot Arm Control Panel</title>
    <style>
        body { font-family: Arial; margin: 20px; }
        input[type=range] { width: 300px; }
        table { border-collapse: collapse; margin-top: 20px; width: 90%; }
        th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
    </style>
</head>
<body>

<h2>Robot Arm Control Panel</h2>
<div id="sliders">
    <div>Motor 1: <input type="range" min="0" max="180" value="90"></div>
    <div>Motor 2: <input type="range" min="0" max="180" value="90"></div>
    <div>Motor 3: <input type="range" min="0" max="180" value="90"></div>
    <div>Motor 4: <input type="range" min="0" max="180" value="90"></div>
    <div>Motor 5: <input type="range" min="0" max="180" value="90"></div>
    <div>Motor 6: <input type="range" min="0" max="180" value="90"></div>
</div>
<br>
<button onclick="reset()">Reset</button>
<button onclick="savePose()">Save Pose</button>
<button onclick="loadTable()">Run</button>

<div id="poseTable"></div>

<script>
function getSliderValues() {
    return Array.from(document.querySelectorAll('input[type=range]')).map(slider => parseInt(slider.value));
}

function reset() {
    document.querySelectorAll('input[type=range]').forEach(slider => slider.value = 90);
}

function savePose() {
    const values = getSliderValues();
    fetch('save_pose.php', {
        method: 'POST',
        body: JSON.stringify(values)
    }).then(() => loadTable());
}

function loadTable() {
    fetch('get_all_poses.php')
        .then(res => res.json())
        .then(data => {
            let html = '<table><tr><th>Motor 1</th><th>Motor 2</th><th>Motor 3</th><th>Motor 4</th><th>Motor 5</th><th>Motor 6</th><th>Action</th></tr>';
            data.forEach(row => {
                html += `<tr>
                    <td>${row.motor1}</td><td>${row.motor2}</td><td>${row.motor3}</td>
                    <td>${row.motor4}</td><td>${row.motor5}</td><td>${row.motor6}</td>
                    <td>
                        <button onclick="loadPose(${row.motor1}, ${row.motor2}, ${row.motor3}, ${row.motor4}, ${row.motor5}, ${row.motor6})">Load</button>
                        <button onclick="removePose(${row.id})">Remove</button>
                    </td>
                </tr>`;
            });
            html += '</table>';
            document.getElementById('poseTable').innerHTML = html;
        });
}

function loadPose(m1, m2, m3, m4, m5, m6) {
    const sliders = document.querySelectorAll('input[type=range]');
    [m1, m2, m3, m4, m5, m6].forEach((val, i) => sliders[i].value = val);
}

function removePose(id) {
    fetch('remove_pose.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'id=' + id
    }).then(() => loadTable());
}

loadTable();
</script>

</body>
</html>
