
<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
$result = $conn->query("SELECT * FROM poses ORDER BY id DESC LIMIT 1");
if ($row = $result->fetch_assoc()) {
    echo $row['id'] . ",";
    echo "s" . $row['motor1'] . ",";
    echo "s" . $row['motor2'] . ",";
    echo "s" . $row['motor3'] . ",";
    echo "s" . $row['motor4'] . ",";
    echo "s" . $row['motor5'] . ",";
    echo "s" . $row['motor6'];
}
?>
