<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");

$result = $conn->query("SELECT * FROM poses ORDER BY id DESC");
$poses = [];

while ($row = $result->fetch_assoc()) {
    $poses[] = $row;
}

header('Content-Type: application/json');
echo json_encode($poses);
?>