
<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
$data = json_decode(file_get_contents("php://input"), true);
$stmt = $conn->prepare("INSERT INTO poses (motor1, motor2, motor3, motor4, motor5, motor6) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("iiiiii", $data[0], $data[1], $data[2], $data[3], $data[4], $data[5]);
$stmt->execute();
echo "Saved";
?>
