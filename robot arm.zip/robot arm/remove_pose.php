
<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
$id = (int)$_POST['id'];
$conn->query("DELETE FROM poses WHERE id = $id");
echo "Removed";
?>
